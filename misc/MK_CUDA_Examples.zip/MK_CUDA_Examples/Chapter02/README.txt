xorNM is the Nelder-Mead version.
xorLM is the Levenberg-Marquardt example. 
  (Must install levmar to build http://www.ics.forth.gr/~lourakis/levmar/)


