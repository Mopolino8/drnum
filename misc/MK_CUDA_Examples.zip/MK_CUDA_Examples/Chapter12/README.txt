MUST have ffmpeg installed

Most users will run in the 640x480 directory. Users with very slow machines
should try the code in the 320x240 directory. The only difference from
a sourcecode standpoint is the definition of mesh size in simpleVBO.cpp
and the frame size passed to ffmpeg.

