The file VS10.bat enables a Visual Studio command-line shell under cygwin

